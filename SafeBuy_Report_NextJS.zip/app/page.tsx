export const metadata = {
  title: 'SafeBuy Report — Verifica venditori, siti e annunci prima di pagare',
  description: 'Analisi rapida via Telegram. Evita truffe su Subito, Marketplace, Vinted, Instagram. Pagamenti Stripe, report entro 20 minuti.',
};

export default function Home() {
  const telegramUsername = '@SafeBuy_Report';
  const STRIPE_LITE = 'https://buy.stripe.com/test_bJedRbboy0Sn8nRgG2f7i02';
  const STRIPE_STD  = 'https://buy.stripe.com/test_5kQeVfaku8kPdIb3Tgf7i00';
  const STRIPE_VIP  = 'https://buy.stripe.com/test_5kQ9AV78i58D6fJ89wf7i01';

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* ... UI Code omitted for brevity ... */}
      <div className="text-center py-20 text-xl">SafeBuy Report — il sito è pronto ✅</div>
    </div>
  );
}
